USE AdventureWorks;
GO

SELECT 
	SalesPersonID
,	LastName
,	TerritoryName
,	CountryRegionName
FROM	Sales.vSalesPerson
WHERE	TerritoryName IS NOT NULL
ORDER BY CASE CountryRegionName WHEN 'United States' THEN TerritoryName
         ELSE CountryRegionName END